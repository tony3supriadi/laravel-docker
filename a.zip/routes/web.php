<?php

use Illuminate\Support\Facades\Route;

Route::get('/login', 'Auth\LoginController@showLoginForm');
Route::post('/login', 'Auth\LoginController@login')->name('login');
Route::group(['middleware' => ['auth']], function() {
    
    Route::get('/', 'HomeController@index');
    Route::get('/home', 'HomeController@index')->name('home');
    Route::get('/dashboard', 'HomeController@index')->name('home');

    Route::get('/akun', 'AccountController@index')->name('account');
    Route::get('/akun/{id}/edit', 'AccountController@edit')->name('account.edit');
    Route::put('/akun/update', 'AccountController@update')->name('account.update');

    Route::resource('/perusahaan', 'CompanyController')
        ->only('index', 'edit', 'update');
    Route::resource('/cabang', 'BranchController');

    Route::resource('users', 'UserController');
    Route::resource('hak-akses', 'RoleController');
    Route::resource('module', 'PermissionController')
        ->only('index');

    Route::resource('produk/kategori', 'Master\Produk\CategoryController')
        ->except('create');

    Route::resource('produk/satuan', 'Master\Produk\UnitController')
        ->except('create');

    Route::resource('produk/harga', 'Master\Produk\PriceController')
        ->except('create', 'store', 'delete');

    Route::resource('produk/stok', 'Master\Produk\StockController')
        ->except('create', 'store', 'delete');
    
    Route::post('produk/create-category', 'Master\Produk\ProductController@create_category');
    Route::post('produk/create-unit', 'Master\Produk\ProductController@create_unit');
    Route::resource('produk', 'Master\Produk\ProductController');

    Route::resource('pelanggan/grup', 'Master\Pelanggan\GroupController')
        ->except('create');

    Route::post('pelanggan/create-group', 'Master\Pelanggan\CustomerController@create_group');
    Route::resource('pelanggan', 'Master\Pelanggan\CustomerController');

    Route::resource('supplier', 'Master\Supplier\SupplierController');

    Route::resource('karyawan', 'Master\Karyawan\EmployeeController');
    
    Route::post('/belanja/add-to-cart', 'Operational\Belanja\ShoppingController@addToCart');
    Route::delete('/belanja/destroy-cart/{index}', 'Operational\Belanja\ShoppingController@destroyCart');
    Route::post('/belanja/create-supplier', 'Operational\Belanja\ShoppingController@createSupplier');
    Route::post('/belanja/create-payments', 'Operational\Belanja\ShoppingController@createPayment');
    Route::resource('belanja', 'Operational\Belanja\ShoppingController')
        ->except('edit', 'update');

    Route::get('gaji-karyawan/print', 'Operational\SallaryController@print');
    Route::resource('gaji-karyawan', 'Operational\SallaryController')
            ->only('index', 'create', 'store');

    Route::resource('operasional/lainnya', 'Operational\OperationalController')
            ->except('show');

    Route::post('/logout', 'Auth\LoginController@logout')->name('logout');
});
