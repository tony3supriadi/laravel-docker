$(document).ready(function() {

    $('.datatable.no-ordering').dataTable({
        "ordering": false
    });

    $('.datatable').dataTable();

});