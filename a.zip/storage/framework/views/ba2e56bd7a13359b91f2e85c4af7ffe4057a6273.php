<?php $__env->startSection('header'); ?>
<header class="page-header position-fixed">
    <div class="container-fluid row">
        <h2 class="no-margin-bottom col-md-6">
            <i class="fa fa-database mr-3"></i>Operasional Lainnya
        </h2>

        <div class="col-md-6 text-right">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('operational-create')): ?>
            <a href="<?php echo e(url('operasional/lainnya/create')); ?>" class="btn btn-primary btn-sm">
                <i class="fa fa-plus-circle mr-2"></i>INPUT DATA
            </a>
            <?php endif; ?>
        </div>
    </div>
</header>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="p-4">
    <div class="row mb-0">
        <div class="col-md-1 py-1">
            FILTER : 
        </div>
        <div class="col-md-6">
            <form action="" method="get">
                <div class="form-group row">
                    <div class="col-3 px-0">
                        <?php $months = [
                            [ 'id' => '01', 'name' => "Januari" ],
                            [ 'id' => '02', 'name'  => "Februari" ],
                            [ 'id' => '03', 'name'  => "Maret" ],
                            [ 'id' => '04', 'name'  => "April" ],
                            [ 'id' => '05', 'name'  => "Mei" ],
                            [ 'id' => '06', 'name'  => "Juni" ],
                            [ 'id' => '07', 'name'  => "Juli" ],
                            [ 'id' => '08', 'name'  => "Agustus" ],
                            [ 'id' => '09', 'name'  => "September" ],
                            [ 'id' => '10', 'name'  => "Oktober" ],
                            [ 'id' => '11', 'name'  => "November" ],
                            [ 'id' => '12', 'name'  => "Desember" ],
                        ]; ?>
                        <select name="m" class="form-control form-control-sm">
                            <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <option value="<?php echo e($m['id']); ?>"
                                    <?php if(isset($_GET['m'])): ?> <?php if($_GET['m'] == $m['id']): ?> selected <?php endif; ?>
                                    <?php elseif($m['id'] == date('m')): ?> selected <?php endif; ?>
                                    ><?php echo e($m['name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-2 px-0">
                        <select name="y" class="form-control form-control-sm">
                            <?php for($i = date('m') != 1 ? date('Y') : (date('Y') - 1); 
                                $i > ((date('m') != 1 ? date('Y') : (date('Y') - 1)) - 5); 
                                $i--): ?>
                            <option value="<?php echo e($i); ?>"
                                <?php if(isset($_GET['y']) && $_GET['y'] == $i): ?> selected <?php endif; ?>
                                ><?php echo e($i); ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="col-3 pr-0">
                        <button type="submit" class="btn btn-sm btn-primary btn-block">
                            TAMPIL
                        </button>
                    </div>
                </div>
            </form>
        </div>
        <div class="col-md-3 offset-md-2">
            <div class="border py-2 px-3 mb-2 text-right">
                <small class="text-secondary">TOTAL BULAN <?php echo e(strtoupper(array_filter($months, function($var) { return ($var['id'] == (isset($_GET['m']) ? $_GET['m'] : date('m'))); })[(isset($_GET['m']) ? $_GET['m'] : date('m')) - 1]['name'])); ?> :</small>
                <h3 class="no-margin-bottom">Rp<?php echo e(number_format($total, 0, ',', '.')); ?>,-</h3>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <table class="table datatable no-ordering">
                <thead>
                    <tr>
                        <th width="10px">#</th>
                        <th>DESKRIPSI</th>
                        <th width="20%" class="text-right">NOMINAL</th>
                        <th width="15%" class="text-center">TANGGAL</th>
                        <th width="8%" class="text-center">AKSI</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $num = 1; ?>
                    <?php $__currentLoopData = $operationals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <tr>
                        <td><?php echo e($num); ?>.</td>
                        <td><?php echo e($item->description ? $item->description : '-'); ?></td>
                        <td class="text-right">Rp<?php echo e(number_format($item->nominal, 0, ',', '.')); ?>,-</td>
                        <td class="text-center"><?php echo e(Carbon\Carbon::parse($item->created_at)->format('d M Y')); ?></td>
                        <td class="text-center">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('operational-edit')): ?>
                            <a href="<?php echo e(url('/operasional/lainnya/'.encrypt($item->id).'/edit')); ?>" class="text-primary">
                                <i class="fa fa-edit"></i>
                            </a>
                            <?php endif; ?>
                            
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('operational-delete')): ?>
                            <a href="javascript:" onclick="_deleted('<?php echo e(md5($item->id)); ?>')" class="no-decoration text-danger mx-1">
                                <i class="fa fa-trash-o"></i>
                            </a>

                            <form id="delete-item-<?php echo e(md5($item->id)); ?>"
                                action="<?php echo e(url('operasional/lainnya/'.encrypt($item->id))); ?>"
                                method="post"
                                style="display: none;"
                            >    
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php $num++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('vendor/datatable/css/dataTables.bootstrap4.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('vendor/select2/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/select2/css/select2-bootstrap4.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('vendor/sweetalert2/sweetalert2.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('vendor/datatable/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatable/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/init/datatable.init.js')); ?>"></script>

<script src="<?php echo e(asset('vendor/select2/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/init/select2.init.js')); ?>"></script>

<script src="<?php echo e(asset('vendor/sweetalert2/sweetalert2.js')); ?>"></script>
<script src="<?php echo e(asset('js/init/sweetalert2.init.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/modules/operational/others/index.blade.php ENDPATH**/ ?>