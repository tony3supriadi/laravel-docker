<?php $__env->startSection('header'); ?>
<header class="page-header position-fixed">
    <div class="container-fluid row">
        <h2 class="no-margin-bottom col-md-6">
            <i class="fa fa-shopping-cart mr-3"></i>Data Belanja
        </h2>
    </div>
</header>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="p-4">
    <?php if(isset($_GET['status']) && ($_GET['status'] == 'lunas' || $_GET['status'] == 'hutang')): ?>
    <div class="row">
        <div class="col-md-3 offset-md-9">
            <div class="border py-2 px-3 text-right">
                <small class="text-secondary">TOTAL <?php echo e($_GET['status'] == 'lunas' ? 'BELANJA' : 'HUTANG'); ?> :</small>
                <h3 class="no-margin-bottom">Rp<?php echo e(number_format($total, 0, ',', '.')); ?>,-</h3>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <div class="row mb-0">
        <div class="col-md-1 py-1">
            FILTER : 
        </div>
        <div class="col-md-6">
            <form action="" method="get">
                <?php if(isset($_GET['status'])): ?>
                <input type="hidden" name="status" value="<?php echo e($_GET['status']); ?>">
                <?php endif; ?>
                <div class="form-group row">
                    <div class="col-4 px-0">
                        <input type="date" name="start" value="<?php echo e(isset($_GET['start']) ? $_GET['start'] : date('Y').'-'.date('m').'-01'); ?>" class="form-control form-control-sm">
                    </div>
                    <div class="col-4 px-0">
                        <input type="date" name="end" value="<?php echo e(isset($_GET['end']) ? $_GET['end'] : date('Y-m-d')); ?>" timezone="Asia/Jakarta" class="form-control form-control-sm">
                    </div>
                    <div class="col-3">
                        <button type="submit" class="btn btn-sm btn-primary btn-block">
                            TAMPIL
                        </button>
                    </div>
                </div>
            </form>
        </div>
        <div class="col-md-5 text-center text-lg-right pt-1">
            <a href="<?php echo e(isset($_GET['start']) ? '?status=semua&start='.$_GET['start'].'&end='.$_GET['end'] : '?status=semua'); ?>"
                class="<?php echo e(isset($_GET['status']) ? $_GET['status'] == 'semua' ? 'text-primary' : 'text-secondary' : 'text-primary'); ?>">
                Semua
            </a> 
            <span class="mx-2 text-gray">|</span> 
            <a href="<?php echo e(isset($_GET['start']) ? '?status=lunas&start='.$_GET['start'].'&end='.$_GET['end'] : '?status=lunas'); ?>"
                class="<?php echo e(isset($_GET['status']) && $_GET['status'] == 'lunas' ? 'text-primary' : 'text-secondary'); ?>">
                Lunas
            </a> 
            <span class="mx-2 text-gray">|</span>
            <a href="<?php echo e(isset($_GET['start']) ? '?status=hutang&start='.$_GET['start'].'&end='.$_GET['end'] : '?status=hutang'); ?>"
                class="<?php echo e(isset($_GET['status']) && $_GET['status'] == 'hutang' ? 'text-primary' : 'text-secondary'); ?>">
                Hutang</a> 
            <span class="mx-2 text-gray">|</span> 
            <a href="<?php echo e(isset($_GET['start']) ? '?status=batal&start='.$_GET['start'].'&end='.$_GET['end'] : '?status=batal'); ?>"
                class="<?php echo e(isset($_GET['status']) && $_GET['status'] == 'batal' ? 'text-primary' : 'text-secondary'); ?>">
                Batal</a>
        </div>
    </div>

    <hr class="mt-0" />

    <table class="table datatable no-ordering">
        <thead>
            <tr>
                <th width="10px" class="text-center no-sort">#</th>
                <th width="14%">INVOICE</th>
                <th>PENYUPLAI</th>
                <th width="20%" class="text-right">TOTAL PEMBAYARAN</th>
                <th width="12%" class="text-center">STATUS</th>
                <th width="18%">TANGGAL BELANJA</th>

                <th width="80px" class="text-center">AKSI</th>
            </tr>
        </thead>
        <tbody>
            <?php $num = 1; ?>
            <?php $__currentLoopData = $shoppings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($num); ?>.</td>
                    <td><?php echo e($item->invoice); ?></td>
                    <td><?php echo e($item->supplier_name); ?></td>
                    <td class="text-right">Rp<?php echo e(number_format($item->price_total, 0, ',', '.')); ?>,-</td>
                    <td class="text-center">
                        <span class="badge badge-pill <?php echo e((($item->status == 'Lunas') ? 'badge-success' : (($item->status == 'Hutang') ? 'badge-danger text-white' : 'badge-secondary'))); ?>">
                            <?php echo e($item->status); ?>

                        </span>
                    </td>
                    <td><?php echo e(Carbon\Carbon::parse($item->created_at)->format('d M Y H:i:s')); ?></td>

                    <td class="text-center">
                        <a href="<?php echo e(url('belanja/'.encrypt($item->id))); ?>" class="text-primary mx-1">
                            <i class="fa fa-search"></i>
                        </a>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('belanja-delete')): ?>
                            <a href="javascript:" 
                                <?php if ($item->status == 'Hutang') : ?>
                                    onclick="_cancel('<?php echo e(md5($item->id)); ?>')"
                                <?php endif; ?>
                                class="no-decoration <?php if($item->status == 'Hutang'): ?> text-danger <?php else: ?> text-secondary <?php endif; ?> mx-1">
                                <i class="fa fa-close"></i>
                            </a>

                            <form id="cancel-item-<?php echo e(md5($item->id)); ?>"
                                action="<?php echo e(url('belanja/'.encrypt($item->id))); ?>"
                                method="post"
                                style="display: none;"
                            >    
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php $num++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('vendor/datatable/css/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/sweetalert2/sweetalert2.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/daterangepicker/daterangepicker.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('vendor/datatable/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatable/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/init/datatable.init.js')); ?>"></script>

<script src="<?php echo e(asset('vendor/sweetalert2/sweetalert2.js')); ?>"></script>
<script src="<?php echo e(asset('js/init/sweetalert2.init.js')); ?>"></script>

<script src="<?php echo e(asset('vendor/daterangepicker/daterangepicker.js')); ?>"></script>
<script src="<?php echo e(asset('js/init/daterange.init.js')); ?>"></script>

<?php if(Session::get('success')): ?>
<script type="text/javascript">
Swal.fire({
    title: 'Berhasil!',
    icon: 'success',
    timer: 2000,
    timerProgressBar: true,
    showConfirmButton: false
})
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/modules/operational/shopping/index.blade.php ENDPATH**/ ?>