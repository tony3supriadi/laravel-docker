<div class="position-fixed">
    <nav class="side-navbar">
        <!-- Sidebar Header-->
        <div class="sidebar-header d-flex align-items-center">
            <div class="avatar">
                <img src="<?php echo e(asset('img/avatar.jpg')); ?>" alt="logo" class="img-fluid rounded-circle">
            </div>
            <div class="title">
                <h1 class="h4"><?php echo e(Auth::user()->name); ?></h1>
                <p><?php echo e('@'.Auth::user()->username); ?></p>
            </div>
        </div>

        <div class="slimscroll-sidebar">
        <!-- Sidebar Navidation Menus-->
        <ul class="list-unstyled">
            <li class="<?= $actived == "dashboard" ? 'active' : '' ?>">
                <a href="<?php echo e(url('/dashboard')); ?>">
                    <i class="fa fa-home"></i> Dashboard 
                </a>
            </li>
            <li class="<?= $actived == "akun" ? 'active' : '' ?>">
                <a href="<?php echo e(url('/akun')); ?>">
                    <i class="fa fa-user-circle"></i> Akunku 
                </a>
            </li>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('company-list')): ?>
            <li class="<?= $actived == "perusahaan" ? 'active' : '' ?>">
                <a href="<?php echo e(url('/perusahaan')); ?>">
                    <i class="fa fa-industry"></i> Perusahaan 
                </a>
            </li>
            <?php endif; ?>

            <?php if(Auth::user()->can('user-list') || 
                 Auth::user()->can('role-list') ||
                 Auth::user()->can('permission-list')): ?>
            <li class="<?= $actived == "users" ? 'active' : '' ?>">
                <a href="#users-dropdown" aria-expanded="<?= $actived == "users" ? 'true' : 'false' ?>" data-toggle="collapse" class="<?= $actived == "users" ? '' : 'collapsed' ?>">
                    <i class="fa fa-user"></i>
                    Users
                </a>

                <ul id="users-dropdown" class="collapse list-unstyled <?= $actived == "users" ? 'show' : '' ?>">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-list')): ?>
                    <li>
                        <a href="<?php echo e(url('users')); ?>">
                            <i class="fa fa-angle-double-right"></i>
                            Data User
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-list')): ?>
                    <li>
                        <a href="<?php echo e(url('hak-akses')); ?>">
                            <i class="fa fa-angle-double-right"></i>
                            Hak Akses
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission-list')): ?>
                    <li>
                        <a href="<?php echo e(url('module')); ?>">
                            <i class="fa fa-angle-double-right"></i>
                            Module
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('report-list')): ?>
            <li class="<?= $actived == "laporan" ? 'active' : '' ?>">
                <a href="<?php echo e(url('/laporan')); ?>">
                    <i class="fa fa-clipboard"></i> Laporan 
                </a>
            </li>
            <?php endif; ?>
        </ul>

        <span class="heading">DATA MASTER</span>
        <ul class="list-unstyled">
            <?php if(Auth::user()->can('produk-list')
                || Auth::user()->can('produk-categiry-list')
                || Auth::user()->can('produk-price-list')
                || Auth::user()->can('produk-stock-list')
                || Auth::user()->can('produk-unit-list')
                || Auth::user()->can('produk-barcode-list')): ?>
            <li class="<?= $actived == "master-produk" ? 'active' : '' ?>">
                <a href="#produkMaster" aria-expanded="<?= $actived == "master-produk" ? 'true' : 'false' ?>" data-toggle="collapse" class="<?= $actived == "master-produk" ? '' : 'collapsed' ?>">
                    <i class="fa fa-cube"></i>
                    Produk
                </a>
                <ul id="produkMaster" class="collapse list-unstyled <?= $actived == "master-produk" ? 'show' : '' ?>">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('produk-list')): ?>
                    <li>
                        <a href="<?php echo e(url('produk')); ?>">
                            <i class="fa fa-angle-double-right"></i>
                            Data Produk
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('produk-category-list')): ?>
                    <li>
                        <a href="<?php echo e(url('produk/kategori')); ?>">
                            <i class="fa fa-angle-double-right"></i>
                            Kategori
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('produk-price-list')): ?>
                    <li>
                        <a href="<?php echo e(url('produk/harga')); ?>">
                            <i class="fa fa-angle-double-right"></i>
                            Atur Harga
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('produk-stock-list')): ?>
                    <li>
                        <a href="<?php echo e(url('produk/stok')); ?>">
                            <i class="fa fa-angle-double-right"></i>
                            Atur Stok
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('produk-unit-list')): ?>
                    <li>
                        <a href="<?php echo e(url('produk/satuan')); ?>">
                            <i class="fa fa-angle-double-right"></i>
                            Satuan
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('produk-barcode-list')): ?>
                    <li>
                        <a href="<?php echo e(url('produk/barcode')); ?>">
                            <i class="fa fa-angle-double-right"></i>
                            Barcode
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>

            <?php if(Auth::user()->can('pelanggan-list')
                || Auth::user()->can('pelanggan-group-list')): ?>
            <li class="<?= $actived == "master-pelanggan" ? 'active' : '' ?>">
                <a href="#pelangganMaster" aria-expanded="<?= $actived == "master-pelanggan" ? 'true' : 'false' ?>" data-toggle="collapse" class="<?= $actived == "master-pelanggan" ? '' : 'collapsed' ?>">
                    <i class="fa fa-address-book-o"></i>
                    Pelanggan
                </a>
                <ul id="pelangganMaster" class="collapse list-unstyled <?= $actived == "master-pelanggan" ? 'show' : '' ?>"">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pelanggan-list')): ?>
                    <li>
                        <a href="<?php echo e(url('pelanggan')); ?>">
                            <i class="fa fa-angle-double-right"></i>
                            Daftar Pelanggan
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pelanggan-group-list')): ?>
                    <li>
                        <a href="<?php echo e(url('pelanggan/grup')); ?>">
                            <i class="fa fa-angle-double-right"></i>
                            Grup Pelanggan
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('supplier-list')): ?>
            <li class="<?= $actived == "master-supplier" ? 'active' : '' ?>">
                <a href="<?php echo e(url('/supplier')); ?>">
                    <i class="fa fa-truck"></i> Supplier 
                </a>
            </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('employee-list')): ?>
            <li class="<?= $actived == "master-karyawan" ? 'active' : '' ?>">
                <a href="<?php echo e(url('/karyawan')); ?>">
                    <i class="fa fa-id-card"></i> Karyawan 
                </a>
            </li>
            <?php endif; ?>
        </ul>

        <span class="heading">DATA OPERASIONAL</span>
        <ul class="list-unstyled">
            <?php if(Auth::user()->can('belanja-create') || 
                Auth::user()->can('belanja-list')): ?>
            <li class="<?= $actived == "op-belanja" ? 'active' : '' ?>">
                <a href="#belanjaOp" aria-expanded="aria-expanded="<?= $actived == "op-belanja" ? 'true' : 'false' ?>" data-toggle="collapse" class="<?= $actived == "op-belanja" ? '' : 'collapsed' ?>">
                    <i class="fa fa-shopping-cart"></i>
                    Belanja
                </a>
                <ul id="belanjaOp" class="collapse list-unstyled <?= $actived == "op-belanja" ? 'show' : '' ?>">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('belanja-create')): ?>
                    <li>
                        <a href="<?php echo e(url('belanja/create')); ?>">
                            <i class="fa fa-angle-double-right"></i>
                            Tambah Data Baru
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('belanja-list')): ?>
                    <li>
                        <a href="<?php echo e(url('belanja')); ?>">
                            <i class="fa fa-angle-double-right"></i>
                            Data Belanja
                        </a>
                    </li>
                    <?php endif; ?>                    
                </ul>
            </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sallary-list')): ?>
            <li class="<?= $actived == "op-sallary" ? 'active' : '' ?>">
                <a href="<?php echo e(url('/gaji-karyawan')); ?>">
                    <i class="fa fa-google-wallet"></i> Gaji Karyawan 
                </a>
            </li>
            <?php endif; ?>
            
            <li class="<?= $actived == "op-lainnya" ? 'active' : '' ?>">
                <a href="<?php echo e(url('operasional/lainnya')); ?>">
                    <i class="fa fa-database"></i> Lainnya 
                </a>
            </li>
        </ul>

        <span class="heading">DATA Penjualan</span>
        <ul class="list-unstyled">
            <li class="<?= $actived == "operasional-lainnya" ? 'active' : '' ?>">
                <a href="<?php echo e(url('/dashboard')); ?>">
                    <i class="fa fa-shopping-bag"></i> Penjualan
                </a>
            </li>
            <li class="<?= $actived == "operasional-lainnya" ? 'active' : '' ?>">
                <a href="<?php echo e(url('/dashboard')); ?>">
                    <i class="fa fa-tags"></i> Status 
                </a>
            </li>
            <li class="<?= $actived == "operasional-lainnya" ? 'active' : '' ?>">
                <a href="<?php echo e(url('/dashboard')); ?>">
                    <i class="fa fa-history"></i> Riwayat 
                </a>
            </li>
        </ul>
        </div>
    </nav>
</div>
<?php /**PATH /var/www/resources/views/layouts/partials/sidebar.blade.php ENDPATH**/ ?>