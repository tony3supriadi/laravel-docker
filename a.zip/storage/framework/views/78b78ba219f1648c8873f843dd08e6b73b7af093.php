<?php $__env->startSection('header'); ?>
<div class="row position-fixed p-0 m-0 w-100">
    <div class="col-md-12 m-0 p-0">
        <div class="py-2 px-3 mb-2 border-bottom">
                <a href="<?php echo e(URL::previous()); ?>" class="btn btn-sm btn-default mr-2 rounded-circle">
                    <i class="fa fa-arrow-left"></i>
                </a>
                INPUT GAJI KARYAWAN
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="p-4">
    <form action="<?php echo e(url('gaji-karyawan')); ?>" method="post" class="row">
        <?php echo csrf_field(); ?>

        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <div class="form-group">
                        <label for="employee_id">Pilih Karyawan</label>
                        <select name="employee_id"
                            data-placeholder=""
                            class="form-control select2"
                            onchange="
                                var val = $(this).val();
                                var employees = <?php echo e($employees); ?>;
                                var filter = employees.filter((item) => {
                                    return item.id == $(this).val();
                                })[0];

                                $('#loading').removeClass('d-none');
                                setTimeout(() => {
                                    $('#loading').addClass('d-none');

                                    $('#info-detail').removeClass('d-none');
                                    $('#extra').removeClass('d-none');
                                    $('input[name=salary]').val(filter.salary);
                                }, 2000);
                            ">
                            <option value=""></option>
                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e(strtoupper($item->name)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <div id="loading" class="d-none">
                            <small>Loading...</small>
                        </div>
                    </div>

                    <div id="info-detail" class="d-none">
                        <div class="form-group">
                            <label for="salary">Gaji Pokok</label>
                            <input type="text" name="salary" value="" class="form-control text-right" readonly>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div id="extra" class="col-md-8 d-none">
            <div class="border p-3">
                <div class="form-group col-6 p-0">
                    <label for="salary-extra">Gaji Tambahan</label>
                    <input type="text" value="0" name="salary_extra" class="form-control text-right">
                </div>

                <div class="form-group">
                    <label for="description">DESKRIPSI</label>
                    <textarea name="description" class="form-control"></textarea>
                    
                    <small class="text-gray">
                        Tambahkan catatan tamabahan mengenai gaji yang diperoleh, <br />misal: gaji tambahan berupa lembur dsb.
                    </small>
                </div>

                <hr />

                <div class="form-group text-right">
                    <button type="submit" class="btn btn-primary">
                        <i class="fa fa-save mr-2"></i>SIMPAN
                    </button>
                </div>
            </div>
        </div>
    </form>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('vendor/select2/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/select2/css/select2-bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('vendor/select2/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/init/select2.init.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/modules/operational/sallary/create.blade.php ENDPATH**/ ?>