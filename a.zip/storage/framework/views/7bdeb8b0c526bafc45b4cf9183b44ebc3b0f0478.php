
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="all,follow">

    <title><?php echo e($title); ?> - SIMKEU (Sistem Management Keuangan)</title>
    
    <link rel="stylesheet" href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/font-awesome/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fontastic.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.sea.css')); ?>" id="theme-stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('img/favicon.ico')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/poppins-family.font.css')); ?>">

    <?php echo $__env->yieldContent('style'); ?>
</head>
<body>
    <div class="page">
        <!-- Main Navbar-->
        <?php echo $__env->make('layouts.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="page-content d-flex align-items-stretch" style="margin-top:70px"> 
            <!-- Side Navbar -->
            <?php echo $__env->make('layouts.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          
            <div class="content-inner">
              <!-- Page Header-->
              <?php echo $__env->yieldContent('header'); ?>

              <!-- Content -->
              <div class="content">
                <div class="slimscroll-content">
                  <?php echo $__env->yieldContent('content'); ?>
                </div>
              </div>
            </div>
        </div>
    </div>
    
    <script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/daterangepicker/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/popper.js/umd/popper.min.js')); ?>"> </script>
    <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/jquery.cookie/jquery.cookie.js')); ?>"> </script>
    <script src="<?php echo e(asset('vendor/slimscroll/jquery.slimscroll.min.js')); ?>"> </script>
    <script src="<?php echo e(asset('js/front.js')); ?>"></script>
    <script src="<?php echo e(asset('js/init/app.js')); ?>"></script>

    <?php echo $__env->yieldContent('script'); ?>
  </body>
</html><?php /**PATH /var/www/resources/views/layouts/app.blade.php ENDPATH**/ ?>