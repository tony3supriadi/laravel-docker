<?php $__env->startSection('header'); ?>
<header class="page-header position-fixed">
    <div class="container-fluid row">
        <h2 class="no-margin-bottom col-md-6">
            <i class="fa fa-google-wallet mr-3"></i>Gaji Karyawan
        </h2>
    </div>
</header>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="p-4">
    <div class="row mb-0">
        <div class="col-md-1 py-1">
            FILTER : 
        </div>
        <div class="col-md-6">
            <form action="" method="get">
                <?php if(isset($_GET['status'])): ?>
                <input type="hidden" name="status" value="<?php echo e($_GET['status']); ?>">
                <?php endif; ?>
                <div class="form-group row">
                    <div class="col-3 px-0">
                        <?php $months = [
                            [ 'id' => '01', 'name' => "Januari" ],
                            [ 'id' => '02', 'name'  => "Februari" ],
                            [ 'id' => '03', 'name'  => "Maret" ],
                            [ 'id' => '04', 'name'  => "April" ],
                            [ 'id' => '05', 'name'  => "Mei" ],
                            [ 'id' => '06', 'name'  => "Juni" ],
                            [ 'id' => '07', 'name'  => "Juli" ],
                            [ 'id' => '08', 'name'  => "Agustus" ],
                            [ 'id' => '09', 'name'  => "September" ],
                            [ 'id' => '10', 'name'  => "Oktober" ],
                            [ 'id' => '11', 'name'  => "November" ],
                            [ 'id' => '12', 'name'  => "Desember" ],
                        ]; ?>
                        <select name="m" class="form-control form-control-sm">
                            <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <option value="<?php echo e($m['id']); ?>"
                                    <?php if(isset($_GET['m'])): ?> <?php if($_GET['m'] == $m['id']): ?> selected <?php endif; ?>
                                    <?php elseif($m['id'] == date('m')): ?> selected <?php endif; ?>
                                    ><?php echo e($m['name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-2 px-0">
                        <select name="y" class="form-control form-control-sm">
                            <?php for($i = date('m') != 1 ? date('Y') : (date('Y') - 1); 
                                $i > ((date('m') != 1 ? date('Y') : (date('Y') - 1)) - 5); 
                                $i--): ?>
                            <option value="<?php echo e($i); ?>"
                                <?php if(isset($_GET['y']) && $_GET['y'] == $i): ?> selected <?php endif; ?>
                                ><?php echo e($i); ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="col-3 pr-0">
                        <button type="submit" class="btn btn-sm btn-primary btn-block">
                            TAMPIL
                        </button>
                    </div>
                    <div class="col-4">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sallary-create')): ?>
                        <a href="<?php echo e(url('gaji-karyawan/create')); ?>" class="btn btn-outline-primary btn-sm">
                            <i class="fa fa-edit mr-1"></i>INPUT GAJI
                        </a>
                        <?php endif; ?>

                        <a href="javascript:" 
                            onclick="
                                $.get('<?php echo e(url('gaji-karyawan/print'.(isset($_GET['m']) ? '?m='.$_GET['m'].'&y='.$_GET['y'] : '' ))); ?>',
                                    function(html) {
                                        var w = document.createElement('iframe');
                                        document.body.appendChild(w);
                                        w.contentDocument.write(html);
                                        w.focus();
                                        w.contentWindow.print();
                                        w.parentNode.removeChild(w) ;
                                    })
                            "
                            class="btn btn-outline-primary btn-sm">
                            
                            <i class="fa fa-print"></i>
                        </a>
                    </div>
                </div>
            </form>
        </div>
        <div class="col-md-3 offset-md-2">
            <div class="border py-2 px-3 mb-2 text-right">
                <small class="text-secondary">TOTAL GAJI BULAN <?php echo e(strtoupper(array_filter($months, function($var) { return ($var['id'] == (isset($_GET['m']) ? $_GET['m'] : date('m'))); })[(isset($_GET['m']) ? $_GET['m'] : date('m')) - 1]['name'])); ?> :</small>
                <h3 class="no-margin-bottom">Rp<?php echo e(number_format($total, 0, ',', '.')); ?>,-</h3>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <table class="table datatable no-ordering">
                <thead>
                    <tr>
                        <th width="10px">#</th>
                        <th width="20%">NAMA KARYAWAN</th>
                        <th width="15%" class="text-right">GAJI POKOK</th>
                        <th width="15%" class="text-right">GAJI TAMBAHAN</th>
                        <th width="15%" class="text-right">TOTAL GAJI</th>
                        <th>DESKRIPSI</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $num = 1; ?>
                    <?php $__currentLoopData = $salaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <tr>
                        <td><?php echo e($num); ?>.</td>
                        <td><?php echo e($item->name); ?></td>
                        <td class="text-right"><?php echo e(number_format($item->salary, 0, ',', '.')); ?></td>
                        <td class="text-right"><?php echo e(number_format($item->salary_extra, 0, ',', '.')); ?></td>
                        <td class="text-right"><?php echo e(number_format($item->salary_total, 0, ',', '.')); ?></td>
                        <td><?php echo e($item->description ? $item->description : '-'); ?></td>
                    </tr>
                    <?php $num++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('vendor/datatable/css/dataTables.bootstrap4.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('vendor/select2/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/select2/css/select2-bootstrap4.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('vendor/sweetalert2/sweetalert2.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('vendor/datatable/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatable/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/init/datatable.init.js')); ?>"></script>

<script src="<?php echo e(asset('vendor/select2/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/init/select2.init.js')); ?>"></script>

<script src="<?php echo e(asset('vendor/sweetalert2/sweetalert2.js')); ?>"></script>
<script src="<?php echo e(asset('js/init/sweetalert2.init.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/modules/operational/sallary/index.blade.php ENDPATH**/ ?>