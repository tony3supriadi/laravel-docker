@extends('layouts.app')

@section('header')
<header class="page-header position-fixed">
    <div class="container-fluid row">
        <h2 class="no-margin-bottom col-md-6">
            <i class="fa fa-credit-card-alt mr-3"></i>Detail Hutang
        </h2>

        <div class="col-md-6 text-right">
            <a href="javascript::" class="btn btn-primary btn-sm">
                <i class="fa fa-plus-circle mr-2"></i>INPUT PEMBAYARAN
            </a>
        </div>
    </div>
</header>
@endsection

@section('content')

@endsection